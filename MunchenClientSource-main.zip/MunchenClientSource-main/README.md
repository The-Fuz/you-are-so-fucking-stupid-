Source Provided By Unixian

This source is about a month old, now compilable for vrchat update fully working.
Have fun, and explore how pasted munchen is while also saying that abyss is a paste.
You can do whatever with this source, since it's been fixed enjoy!

Bunny & _Unreal Says Hi.
ALWAYS ON TOP. NEVER DEFEATED.
- Unixian#4669


TO KILLER:
- Why couldn't you just leave people alone?

GREETZ:
- [Bunny]#0534
- _Unreal#8642
- Charliee#1400
- Anyone else that i showed munchen source

TO UNIXIAN:
- Thanks for being real & supporting us in everything we do.
You have been one of the most amazing people.
Even if killer hates you, i don't see the point in the hate.
This community is so toxic & their hate leads to their demise.

DISCLAIMER:
- Don't buy munchen since it's entirely pasted from advanced safety, chromatica api, other clients that astro has provided.
