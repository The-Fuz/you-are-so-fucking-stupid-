namespace UnchainedButtonAPI
{
	internal enum QuickMenus : short
	{
		Unknown = -1,
		LaunchPad,
		Notifications,
		Here,
		Camera,
		AudioSettings,
		ChangeAudioInputDevice,
		Settings,
		Emojis,
		DevTools,
		SelectedUser,
		HoveredUser
	}
}
