using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Security;
using System.Security.Permissions;
using MelonLoader;
using MunchenClient.Core;

[assembly: MelonGame("VRChat", "VRChat")]
[assembly: MelonInfo(typeof(MunchenClientLocal), "MunchenClient - VRChat", "2.0.0", "Photon Bot & Unixian", "https://shintostudios.net")]
[assembly: AssemblyTitle("MunchenClient")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Shinto Studios")]
[assembly: AssemblyProduct("MunchenClient")]
[assembly: AssemblyCopyright("Copyright © 2020")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("2ee8da08-2ab3-467d-9270-e52393b6fe96")]
[assembly: AssemblyFileVersion("1.3.3.7")]
[assembly: AssemblyVersion("1.3.3.7")]
