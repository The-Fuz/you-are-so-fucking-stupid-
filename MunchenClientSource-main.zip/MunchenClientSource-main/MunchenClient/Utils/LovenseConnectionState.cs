namespace MunchenClient.Utils
{
	internal enum LovenseConnectionState
	{
		Disconnected,
		Connecting,
		Connected
	}
}
