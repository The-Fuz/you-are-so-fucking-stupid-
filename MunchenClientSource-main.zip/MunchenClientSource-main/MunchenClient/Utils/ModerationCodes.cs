namespace MunchenClient.Utils
{
	internal enum ModerationCodes : byte
	{
		PotentialWarning = 2,
		MicOff = 8,
		Friend = 10,
		Votekick = 13,
		PlayerAwareList = 20,
		MuteAndBlock = 21
	}
}
