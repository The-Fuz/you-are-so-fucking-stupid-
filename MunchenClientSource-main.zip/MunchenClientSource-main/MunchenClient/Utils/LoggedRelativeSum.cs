namespace MunchenClient.Utils
{
	internal class LoggedRelativeSum
	{
		internal int sum;

		internal float lastSeen;

		internal int totalDetections;
	}
}
