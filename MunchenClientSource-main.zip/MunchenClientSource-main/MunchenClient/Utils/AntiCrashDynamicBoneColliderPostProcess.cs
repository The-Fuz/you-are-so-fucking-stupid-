namespace MunchenClient.Utils
{
	internal class AntiCrashDynamicBoneColliderPostProcess
	{
		internal int nukedDynamicBoneColliders;

		internal int dynamicBoneColiderCount;
	}
}
