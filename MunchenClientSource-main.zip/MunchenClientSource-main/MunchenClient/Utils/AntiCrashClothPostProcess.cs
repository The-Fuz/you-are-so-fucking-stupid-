namespace MunchenClient.Utils
{
	internal class AntiCrashClothPostProcess
	{
		internal int nukedCloths;

		internal int clothCount;

		internal int currentVertexCount;
	}
}
