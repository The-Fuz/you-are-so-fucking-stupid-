namespace MunchenClient.Utils
{
	internal enum LovenseDeviceType : byte
	{
		Generic,
		AirPump,
		Rotate,
		DoubleVibrate
	}
}
