namespace MunchenClient.Utils
{
	internal class AntiCrashDynamicBonePostProcess
	{
		internal int nukedDynamicBones;

		internal int dynamicBoneCount;
	}
}
