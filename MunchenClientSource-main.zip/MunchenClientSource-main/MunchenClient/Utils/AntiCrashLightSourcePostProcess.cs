namespace MunchenClient.Utils
{
	internal class AntiCrashLightSourcePostProcess
	{
		internal int nukedLightSources;

		internal int lightSourceCount;
	}
}
