namespace MunchenClient.Utils
{
	public class PlayerBlockedEvents
	{
		public bool BlockedRPC;

		public bool BlockedUdon;

		public bool BlockedPhoton;
	}
}
