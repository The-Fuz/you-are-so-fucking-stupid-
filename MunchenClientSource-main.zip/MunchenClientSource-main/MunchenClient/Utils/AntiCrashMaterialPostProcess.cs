namespace MunchenClient.Utils
{
	internal class AntiCrashMaterialPostProcess
	{
		internal int nukedMaterials;

		internal int materialCount;
	}
}
