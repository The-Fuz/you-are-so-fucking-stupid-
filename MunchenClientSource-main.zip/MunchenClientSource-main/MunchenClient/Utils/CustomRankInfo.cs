using UnityEngine;

namespace MunchenClient.Utils
{
	internal class CustomRankInfo
	{
		internal bool customRankEnabled;

		internal string customRank;

		internal bool customRankColorEnabled;

		internal Color customRankColor;
	}
}
