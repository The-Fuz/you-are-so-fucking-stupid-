namespace MunchenClient.Utils
{
	internal class AntiCrashShaderPostProcess
	{
		internal int nukedShaders;

		internal int shaderCount;
	}
}
