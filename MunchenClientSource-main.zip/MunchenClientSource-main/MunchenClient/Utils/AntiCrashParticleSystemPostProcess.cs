namespace MunchenClient.Utils
{
	internal class AntiCrashParticleSystemPostProcess
	{
		internal int nukedParticleSystems;

		internal int currentParticleCount;
	}
}
