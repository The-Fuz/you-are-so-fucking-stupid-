namespace MunchenClient.ModuleSystem.Modules
{
	internal enum DPSType : byte
	{
		None,
		Penetrator,
		Oriface
	}
}
