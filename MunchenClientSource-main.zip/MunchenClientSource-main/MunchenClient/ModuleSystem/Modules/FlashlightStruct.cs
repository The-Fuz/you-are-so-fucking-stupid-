using UnityEngine;

namespace MunchenClient.ModuleSystem.Modules
{
	internal class FlashlightStruct
	{
		internal GameObject flashlightObject;

		internal Light flashlightComponent;
	}
}
