namespace MunchenClient.ModuleSystem.Modules
{
	public class PlayerLovensePermissions
	{
		public bool Whitelisted;
	}
}
