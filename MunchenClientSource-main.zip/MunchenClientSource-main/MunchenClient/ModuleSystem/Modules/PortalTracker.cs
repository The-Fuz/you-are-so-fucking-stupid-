namespace MunchenClient.ModuleSystem.Modules
{
	internal class PortalTracker
	{
		internal PortalInternal portal;

		internal float lastTimerSet;

		internal float lastPortalTimer;

		internal bool checkedWorld;

		internal string owner;

		internal bool isMine;
	}
}
