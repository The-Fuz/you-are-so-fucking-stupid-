namespace MunchenClient.ModuleSystem.Modules
{
	public struct SavedAvatar
	{
		public string ID;

		public string Name;
	}
}
