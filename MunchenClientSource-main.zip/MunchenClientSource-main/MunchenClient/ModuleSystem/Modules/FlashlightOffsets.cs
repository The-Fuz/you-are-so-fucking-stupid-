using UnityEngine;

namespace MunchenClient.ModuleSystem.Modules
{
	internal struct FlashlightOffsets
	{
		internal Vector3 positionOffset;

		internal Vector3 rotationOffset;
	}
}
