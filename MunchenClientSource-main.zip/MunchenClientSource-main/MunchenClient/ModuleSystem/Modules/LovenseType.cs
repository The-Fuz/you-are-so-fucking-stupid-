namespace MunchenClient.ModuleSystem.Modules
{
	internal enum LovenseType : byte
	{
		Unknown,
		Touch,
		Feel
	}
}
