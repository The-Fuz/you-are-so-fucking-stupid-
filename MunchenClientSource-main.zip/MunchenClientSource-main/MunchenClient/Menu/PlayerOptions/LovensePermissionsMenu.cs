using UnchainedButtonAPI;

namespace MunchenClient.Menu.PlayerOptions
{
	internal class LovensePermissionsMenu : QuickMenuNestedMenu
	{
		internal LovensePermissionsMenu(QuickMenuButtonRow parent)
			: base(parent, "Lovense Permissions", "Haha lovense go brr")
		{
		}
	}
}
