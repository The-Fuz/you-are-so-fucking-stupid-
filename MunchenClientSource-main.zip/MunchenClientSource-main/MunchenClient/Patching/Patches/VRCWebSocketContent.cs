namespace MunchenClient.Patching.Patches
{
	public class VRCWebSocketContent
	{
		public string userId;

		public VRCUser user;

		public string location;

		public string travelingToLocation;

		public string instance;

		public VRCWorld world;

		public bool canRequestInvite;
	}
}
