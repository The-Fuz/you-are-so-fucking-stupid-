using System;

namespace MunchenClient.Patching.Patches
{
	public class VRCNotificationDetails
	{
		public string requestMessage;

		public DateTime created_at;
	}
}
