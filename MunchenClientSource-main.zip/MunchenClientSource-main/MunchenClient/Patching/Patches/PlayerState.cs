namespace MunchenClient.Patching.Patches
{
	internal class PlayerState
	{
		internal string username;

		internal string joinState;

		internal string location;
	}
}
