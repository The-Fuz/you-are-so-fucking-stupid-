namespace MunchenClient.Patching.Patches
{
	internal enum ObjectTriggerType
	{
		Everybody,
		MasterOnly,
		LocalOnly
	}
}
