namespace MunchenClient.Patching.Patches
{
	public class VRCWebSocketObject
	{
		public string type;

		public string content;
	}
}
