namespace MunchenClient.Patching.Patches
{
	public class VRCNotification
	{
		public string id;

		public string type;

		public string senderUserId;

		public string senderUsername;

		public string receiverUserId;

		public string message;

		public VRCNotificationDetails details;
	}
}
