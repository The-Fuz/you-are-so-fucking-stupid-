namespace MunchenClient.Patching.Patches
{
	internal enum WorldTriggerType
	{
		FullyNetworked,
		MasterOnlyNetworked,
		PartiallyNetworked,
		NotNetworked
	}
}
