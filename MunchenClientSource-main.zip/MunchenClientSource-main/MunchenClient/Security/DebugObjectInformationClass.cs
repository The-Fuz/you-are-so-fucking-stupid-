using System;

namespace MunchenClient.Security
{
	[Flags]
	internal enum DebugObjectInformationClass
	{
		DebugObjectFlags = 1,
		MaxDebugObjectInfoClass = 2
	}
}
